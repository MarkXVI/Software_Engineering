package com.example.lab2.ui.questions;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab2.R;

import java.util.ArrayList;

public class Q_Adapter extends RecyclerView.Adapter<Q_Adapter.ViewHolder> {

    private ArrayList<String> rowsList;

    public Q_Adapter(ArrayList<String> rowsList) {
        this.rowsList = rowsList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView startTextView;
        public CardView questionCard;

        public ViewHolder(View view) {
            super(view);
            startTextView = view.findViewById(R.id.textView_QuestionTopic);
            questionCard = view.findViewById(R.id.card_Question);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_questions, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.startTextView.setText(rowsList.get(position));
        holder.questionCard.setOnClickListener(view -> {
            Intent intent = new Intent(view.getContext(), HealthActivity.class);
            intent.putExtra("topic", rowsList.get(position));
            view.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return rowsList.size();
    }
}
