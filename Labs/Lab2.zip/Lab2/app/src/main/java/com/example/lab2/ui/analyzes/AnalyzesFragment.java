package com.example.lab2.ui.analyzes;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lab2.R;
import com.example.lab2.ui.questions.HealthActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

//Get the result from “Questions” tab and present them on this tab in text and visualize the
//result.
//Summarize the results in text, for example “Based on your answers you have slept well, you
//have eaten well, no stress and no alcohol consumption”.
//Also visualize the result in a bar chart. (1258) How To Implement Bar Chart Graph in Android
//Studio | Android Chart Tutorial 2022 - YouTube
//It is acceptable to use another chart (if you wish) to visualize the results.

public class AnalyzesFragment extends Fragment {
    private BarChart barChart;
    private BarData barData;
    private BarDataSet barDataSet;
    private ArrayList<BarEntry> barEntriesList;
    private Handler handler = new Handler();
    private Runnable runnable;
    private int delay = 1000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_analyzes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View itemView, @Nullable Bundle savedInstanceState) {
        try {
            createChart(itemView);
        } catch (IOException e) {
            e.printStackTrace();
        }
        handler.postDelayed(() -> {
            handler.postDelayed(runnable, delay);
            try {
                createChart(itemView);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }, delay);
    }

    private void createChart(View itemView) throws IOException {
        barChart = itemView.findViewById(R.id.barChart_Analysis);
        getBarChartData(itemView);
        barDataSet = new BarDataSet(barEntriesList, "Scores");
        barData = new BarData(barDataSet);
        barChart.setData(barData);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setColor(getResources().getColor(R.color.purple_200));
        barDataSet.setValueTextSize(16f);
        barChart.getDescription().setEnabled(false);
        barChart.setScaleEnabled(false);
        String[] labels = new String[]{"", "Sleep", "Nutrition", "Stress", "Alcohol"};
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
    }

    private List<HealthActivity.Health> getBarChartData(View itemView) throws IOException {
        TextView currentHealth = itemView.findViewById(R.id.textView_currentHealth);
        barEntriesList = new ArrayList<>();

        List<HealthActivity.Health> healthInfo = readCsv(new FileInputStream((requireContext().getFilesDir().getPath() + "/result.csv")));
        currentHealth.setText(getHealthText(healthInfo.get(0)));
        barEntriesList.add(new BarEntry(1f, healthInfo.get(0).sleep));
        barEntriesList.add(new BarEntry(2f, healthInfo.get(0).nutrition));
        barEntriesList.add(new BarEntry(3f, healthInfo.get(0).stress));
        barEntriesList.add(new BarEntry(4f, healthInfo.get(0).alcohol));
        return healthInfo;
    }

    private String getHealthText(HealthActivity.Health healthInfo) {
        String healthStory = "";
        healthStory += "You slept " + (healthInfo.sleep >= 1 ? "pretty well." : "not so well.") + " ";
        healthStory += "You have been " + (healthInfo.nutrition >= 1 ? "eating well." : "not eating so well.") + " ";
        healthStory += "You have been " + (healthInfo.stress >= 1 ? "managing stress well." : "not managing stress well.") + " ";
        healthStory += "You have been " + (healthInfo.alcohol >= 1 ? "drinking responsibly." : "not drinking responsibly.") + " ";
        return healthStory;
    }

    // read from the CSV file
    private List<HealthActivity.Health> readCsv(InputStream inputStream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String header = reader.readLine();
        List<HealthActivity.Health> healthList = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            if (!line.trim().isEmpty()) {
                String[] data = line.split(",", 4);
                int sleep = Integer.parseInt(data[0].trim());
                int nutrition = Integer.parseInt(data[1].trim());
                int stress = Integer.parseInt(data[2].trim());
                int alcohol = Integer.parseInt(data[3].trim());
                HealthActivity.Health health = new HealthActivity.Health(sleep, nutrition, stress, alcohol);
                healthList.add(health);
            }
        }
        return healthList;
    }
}

