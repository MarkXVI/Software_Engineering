package com.example.lab2.ui.questions;

import android.content.Context;

import org.tensorflow.lite.support.label.Category;
import org.tensorflow.lite.task.core.BaseOptions;
import org.tensorflow.lite.task.core.ComputeSettings;
import org.tensorflow.lite.task.text.nlclassifier.BertNLClassifier;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;

class TextClassificationHelper {
    private Context context;
    private TextResultsListener listener;
    private BertNLClassifier bertClassifier;
    private ScheduledThreadPoolExecutor executor;
    private static final String MOBILEBERT = "mobilebert.tflite";

    public TextClassificationHelper(Context context, TextResultsListener listener) throws IOException {
        this.context = context;
        this.listener = listener;
        initClassifier();
    }

    private void initClassifier() throws IOException {
        BaseOptions baseOptions = new BaseOptions.Builder() {
            @Override
            public BaseOptions.Builder setComputeSettings(ComputeSettings computeSettings) {
                return null;
            }

            @Override
            public BaseOptions.Builder setNumThreads(int i) {
                return null;
            }

            @Override
            public BaseOptions build() {
                return null;
            }
        }
                .setNumThreads(4)
                .build();

        BertNLClassifier.BertNLClassifierOptions options = new BertNLClassifier.BertNLClassifierOptions.Builder() {
            @Override
            public BertNLClassifier.BertNLClassifierOptions.Builder setBaseOptions(BaseOptions baseOptions) {
                return null;
            }

            @Override
            public BertNLClassifier.BertNLClassifierOptions.Builder setMaxSeqLen(int i) {
                return null;
            }

            @Override
            public BertNLClassifier.BertNLClassifierOptions build() {
                return null;
            }
        }
                .setBaseOptions(baseOptions)
                .setMaxSeqLen(128)
                .build();

        bertClassifier = BertNLClassifier.createFromFileAndOptions(context, MOBILEBERT, options);
    }

    public void classify(String text) {
        executor = new ScheduledThreadPoolExecutor(1);
        executor.execute(() -> {
            // Classify the text
            List<Category> results = bertClassifier.classify(text);
            listener.onResult(results);
        });
    }

    public interface TextResultsListener {
        void onError(String error);
        void onResult(List<Category> results);
    }
}
