package com.example.lab2.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lab2.R;

import java.util.ArrayList;

public class YT_Adapter extends RecyclerView.Adapter<YT_Adapter.ViewHolder> {

    private final ArrayList<String> localDataThumbnailUrls;
    Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public String getDataAtPosition(int position) {
//        Log.i("YT_ADAPTER", localDataThumbnailUrls.get(position));
        return localDataThumbnailUrls.get(position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView thumbnail;

        public ViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View
            thumbnail = view.findViewById(R.id.YT_Thumbnail);
        }

        public ImageView getImageView() {
            return thumbnail;
        }
    }

    public YT_Adapter (ArrayList<String> ThumbnailUrls, Context context) {
        localDataThumbnailUrls = ThumbnailUrls;
        this.context = context;
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_thumbnail, viewGroup, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        Glide.with(context)
                .load(localDataThumbnailUrls.get(position))
                .into(viewHolder.getImageView());

        viewHolder.itemView.setOnClickListener(view -> listener.onItemClick(view, position));
    }

    @Override
    public int getItemCount() {
        return localDataThumbnailUrls.size();
    }
}
