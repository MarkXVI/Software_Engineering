package com.example.lab2.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.example.lab2.MainActivity;
import com.example.lab2.R;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class YoutubeActivity extends YouTubeBaseActivity {

    private final String TAG = "YoutubeActivity";
    YouTubePlayerView youTubePlayerView;
    String videoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);

        videoId = getIntent().getStringExtra("videoId");

        Button goBack = findViewById(R.id.YT_Go_Back);
        goBack.setOnClickListener((View) -> {
            Intent intent = new Intent(getBaseContext(), MainActivity.class);
            startActivity(intent);
        });

        youTubePlayerView = findViewById(R.id.YT_Player);
        youTubePlayerView.initialize("AIzaSyCg7YNTmUD8QYJ8Z_aQAS5rp0ydeHi6c-s", new YouTubePlayer.OnInitializedListener() {
                @Override
                public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
                    youTubePlayer.cueVideo(videoId);
                    youTubePlayer.play();
                    Log.i(TAG, "Success!");
                };
                @Override
                public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                    Log.i(TAG, "Failed!");
                    if (youTubeInitializationResult.isUserRecoverableError()) {
                        youTubeInitializationResult.getErrorDialog(YoutubeActivity.this, 1).show();
                    } else {
                        String error = String.format(getString(R.string.player_error), youTubeInitializationResult);
                        Toast.makeText(YoutubeActivity.this, error, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );
    }
}