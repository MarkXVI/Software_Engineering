package com.example.lab2;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.lab2.ui.analyzes.AnalyzesFragment;
import com.example.lab2.ui.home.HomeFragment;
import com.example.lab2.ui.questions.QuestionsFragment;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new HomeFragment();
            case 1:
                return new QuestionsFragment();
            case 2:
                return new AnalyzesFragment();
        }
        return null;
    }

    @Override
    public int getCount() {
        return 3;
    }
}