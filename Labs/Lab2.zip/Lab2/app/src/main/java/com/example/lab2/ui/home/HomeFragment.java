package com.example.lab2.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab2.databinding.FragmentHomeBinding;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//This tab will consist of a description what mental health is and following videos that the user
//can choose to view:
//- Film 1 - Introduction to mental health Top 10 tips to maintain your mental health - YouTube
//- Film 2 - Sleep and mental health (1258) Understanding our sleep cycle: REM and non-REM
//sleep - YouTube
//- Film 3 - Nutrition and mental health (1258) How the food you eat affects your brain - Mia
//Nacamulli - YouTube
//- Film 4 - Stress and mental health (1258) We All Have Mental Health - YouTube
//- Film 5 - Alcohol and mental health (1258) Alcohol and mental health - YouTube
//Challenge yourself and create a horizontal list containing the videos.
//The description (information about mental health): write by yourself at least one sentence
//about sleep, nutrition, stress and alcohol. You can have the title and optionally add a link to
//the text about mental health on Wikipedia.

public class HomeFragment extends Fragment {

    private final String[] YT_Urls= {
            "https://www.youtube.com/watch?v=-OAjfrhuwRk",
            "https://www.youtube.com/watch?v=98V1q5k8x5E",
            "https://www.youtube.com/watch?v=xyQY8a-ng6g",
            "https://www.youtube.com/watch?v=DxIDKZHW3-E",
            "https://www.youtube.com/watch?v=hzcZd08PqSQ"
    };

    ArrayList<String> YT_ThumbnailUrls = new ArrayList<>();
    ArrayList<String> YT_IDs = new ArrayList<>();

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        for (String url : YT_Urls) {
            String id = extractYT_ID(url);
            YT_IDs.add(id);
            YT_ThumbnailUrls.add("https://img.youtube.com/vi/" + id + "/hqdefault.jpg");
        }

        Log.i( "Home Fragment", "thumbnail urls: " + YT_ThumbnailUrls.toString());

        YT_Adapter yt_adapter = new YT_Adapter(YT_ThumbnailUrls, requireContext());
        RecyclerView recyclerView = binding.recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(yt_adapter);

        yt_adapter.setOnItemClickListener((view, position) -> {
//            This opens the video in the YouTube app
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+YT_IDs.get(position)));
            intent.putExtra("VIDEO_ID", YT_IDs.get(position));
            startActivity(intent);

//            This used a new Activity, But it kept crashing...

//            Intent intent = new Intent(requireContext(), YoutubeActivity.class);
//            intent.putExtra("videoId", YT_IDs.get(position));
//            startActivity(intent);
        });

        binding.articleButton.setOnClickListener((view) -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://en.wikipedia.org/wiki/Mental_health"));
            startActivity(browserIntent);
        });

        return root;
    }

    private String extractYT_ID(String YT_Url) {
        String YT_ID = null;
        Pattern pattern = Pattern.compile("http(?:s)?:\\/\\/(?:m.)?(?:www\\.)?youtu(?:\\.be\\/|be\\.com\\/(?:watch\\?(?:feature=youtu.be\\&)?v=|v\\/|embed\\/|user\\/(?:[\\w#]+\\/)+))([^&#?\\n]+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(YT_Url);
        if (matcher.matches()){
            YT_ID = matcher.group(1);
        }
        return YT_ID;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}