package com.example.lab2.ui.questions;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lab2.databinding.ActivityBertBinding;

import org.tensorflow.lite.support.label.Category;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HealthActivity extends AppCompatActivity {
    private ActivityBertBinding activityBertBinding;
    private TextClassificationHelper classifierHelper;
    private String topic;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityBertBinding = ActivityBertBinding.inflate(getLayoutInflater());
        setContentView(activityBertBinding.getRoot());
        topic = getIntent().getExtras().getString("topic");
        String question = "How is everything with " + topic + " today?";
        activityBertBinding.textViewQuestionnaireQuestion.setText(question);

        try {
            classifierHelper = new TextClassificationHelper(this, listener);
        } catch (IOException e) {
            e.printStackTrace();
        }

        activityBertBinding.buttonQuestionnaireSubmit.setOnClickListener(view -> {
            if (Objects.requireNonNull(activityBertBinding.editTextQuestionnaireInput.getText()).toString().isEmpty()) {
                Log.d("BertActivity", "Nothing to classify");
            } else {
                classifierHelper.classify(activityBertBinding.editTextQuestionnaireInput.getText().toString());
            }
        });
    }


    private final TextClassificationHelper.TextResultsListener listener = new TextClassificationHelper.TextResultsListener() {
        @Override
        public void onError(String error) {
            Toast.makeText(getBaseContext(), error, Toast.LENGTH_SHORT).show();
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        public void onResult(List<Category> results) {
            runOnUiThread(() -> {
                List<Health> healthInfo = null;
                try {
                    healthInfo = readCsv(new FileInputStream(getFilesDir().getPath() + "result.csv"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                assert healthInfo != null;

                //Attach the new information
                int score = results.get(0).getScore() > 0.5 ? -1 : 1;
                switch (topic) {
                    case "Sleep":
                        healthInfo.get(0).sleep += score;
                        break;
                    case "Nutrition":
                        healthInfo.get(0).nutrition += score;
                        break;
                    case "Stress":
                        healthInfo.get(0).stress += score;
                        break;
                    case "Alcohol":
                        healthInfo.get(0).alcohol += score;
                        break;
                    default:
                        Log.d("BertActivity", "Failed to add score");
                }
                Log.d("BertBefore", String.valueOf(healthInfo));

                writeCsv(healthInfo);
                finish();
            });
        }
    };

    // Write to the file again with "new" information included
    private void writeCsv(List<Health> healthInfo) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(getFilesDir().getPath() + "result.csv"));
            writer.write("'Sleep', 'Nutrition', 'Stress', 'Alcohol'");
            writer.newLine();
            writer.write(healthInfo.get(0).sleep + ", " + healthInfo.get(0).nutrition + ", " + healthInfo.get(0).stress + ", " + healthInfo.get(0).alcohol);
            writer.newLine();
            writer.flush();
            Log.d("BertAfter", healthInfo.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // read from the CSV file
    private List<Health> readCsv(InputStream inputStream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        reader.readLine();
        List<Health> healthList = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            if (!line.trim().isEmpty()) {
                String[] data = line.split(",", 4);
                int sleep = Integer.parseInt(data[0].trim());
                int nutrition = Integer.parseInt(data[1].trim());
                int stress = Integer.parseInt(data[2].trim());
                int alcohol = Integer.parseInt(data[3].trim());
                Health health = new Health(sleep, nutrition, stress, alcohol);
                healthList.add(health);
            }
        }
        return healthList;
    }

    public static class Health {
        public int sleep;
        public int nutrition;
        public int stress;
        public int alcohol;

        public Health(int sleep, int nutrition, int stress, int alcohol) {
            this.sleep = sleep;
            this.nutrition = nutrition;
            this.stress = stress;
            this.alcohol = alcohol;
        }

        @Override
        public String toString() {
            return "Health{" +
                    "sleep=" + sleep +
                    ", nutrition=" + nutrition +
                    ", stress=" + stress +
                    ", alcohol=" + alcohol +
                    '}';
        }
    }
}

